<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="小房子" tilewidth="10" tileheight="10" tilecount="484" columns="22">
 <image source="png文件/5.png" width="222" height="225"/>
</tileset>
