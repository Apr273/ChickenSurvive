<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="地图1" tilewidth="10" tileheight="10" tilecount="3264" columns="64">
 <image source="png文件/4.png" width="644" height="515"/>
</tileset>
