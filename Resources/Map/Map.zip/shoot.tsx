<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="子弹" tilewidth="10" tileheight="10" tilecount="124" columns="4">
 <image source="png文件/7.svg" width="49" height="318"/>
</tileset>
