<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="meta" tilewidth="10" tileheight="10" tilecount="78" columns="13">
 <image source="../meta.png" width="134" height="68"/>
 <tile id="15">
  <properties>
   <property name="Collidable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="16">
  <properties>
   <property name="Collidable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="17">
  <properties>
   <property name="Collidable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="28">
  <properties>
   <property name="Collidable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="29">
  <properties>
   <property name="Collidable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="30">
  <properties>
   <property name="Collidable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="41">
  <properties>
   <property name="Collidable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="42">
  <properties>
   <property name="Collidable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="43">
  <properties>
   <property name="Collidable" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="44">
  <properties>
   <property name="Collidable" type="bool" value="false"/>//修改
  </properties>
 </tile>
 <tile id="56">
  <properties>
   <property name="Collidable" type="bool" value="false"/>
  </properties>
 </tile>
 <tile id="57">
  <properties>
   <property name="Collidable" type="bool" value="false"/>
  </properties>
 </tile>
</tileset>
