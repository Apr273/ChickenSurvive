<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="树木" tilewidth="32" tileheight="32" tilecount="6" columns="2">
 <image source="《甲武天图》仙侠类游戏素材-书目(shumu)_爱给网_aigei_com.png" width="88" height="112"/>
</tileset>
