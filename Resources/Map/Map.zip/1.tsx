<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="1" tilewidth="10" tileheight="10" tilecount="299" columns="23">
 <image source="png文件/1.png" width="239" height="134"/>
</tileset>
