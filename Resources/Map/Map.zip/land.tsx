<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="绿地" tilewidth="32" tileheight="32" tilecount="400" columns="20">
 <image source="不错的RPG游戏草地地图素材-草_14(grass_14)_爱给网_aigei_com.png" width="640" height="640"/>
</tileset>
